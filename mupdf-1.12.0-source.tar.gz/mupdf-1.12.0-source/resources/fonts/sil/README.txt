This is a 'dumb' version of Charis SIL, created by taking the
plain glyphs from the design source postscript outlines and stripping
away all of the alternates and OpenType smarts.
